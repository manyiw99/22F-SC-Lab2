package Card;

public enum Suit {
    LEAF, FIREWORKS, STOP, STRAIGHT, PM, MUL2, BONUS
}
